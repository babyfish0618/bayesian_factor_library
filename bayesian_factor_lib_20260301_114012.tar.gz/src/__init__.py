"""
贝叶斯因子库维护系统

从AlphaPROBE论文中抽取贝叶斯检索器模块，
独立应用于因子库维护问题。
"""

__version__ = "0.1.0"
__author__ = "小鱼爬爬量化研究助手"

from .mvp_selector import Factor, MVPBayesianSelector

__all__ = ['Factor', 'MVPBayesianSelector']